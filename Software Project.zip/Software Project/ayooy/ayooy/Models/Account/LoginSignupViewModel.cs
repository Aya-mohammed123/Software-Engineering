﻿using System.ComponentModel.DataAnnotations;

namespace ayooy.Models.Account
{
	public class LoginSignupViewModel
	{
		public int Id { get; set; }
		public string Username { get; set; }
		public string Email { get; set; }
		public string Mobile { get; set; }
		[Required(ErrorMessage = "Please,enter password")]
		[DataType(DataType.Password)]
		public string Password { get; set; }
		[Display(Name = "Confirm Password")]
		[Required(ErrorMessage = "Please,enter confirm password")]
		[Compare("Password", ErrorMessage = "password and confirm password dosn't match")]
		public string ConfirmPassword { get; set; }
		public bool IsActive { get; set; }
		public bool IsRemember { get; set; }
	}
}
