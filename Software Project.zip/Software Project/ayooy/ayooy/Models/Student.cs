﻿using ayooy.Models.Account;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ayooy.Models
{
	public class Student
	{ 

		[Key, ForeignKey("User")]
		public int Id { get; set; }
		public string Name { get; set; }
		 
		public string Address { get; set; }
		public float? GPA { get; set; }
		public byte[]? image { get; set; }


		// Navigation property to the associated User
		public virtual User User { get; set; }
		// Navigation property for Faculty (1:M relationship)
		public int FacultyId { get; set; }
		public virtual Faculty Faculty { get; set; }
		 
		public virtual ICollection<Registration> Registrations { get; set; }
	}
}
