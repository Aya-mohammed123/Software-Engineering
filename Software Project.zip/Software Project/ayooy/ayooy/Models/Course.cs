﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;

namespace ayooy.Models
{
	public class Course
	{
		[Key]
		public int Code { get; set; }

		public string CreditHour { get; set; }

		public string Name { get; set; }
        [ValidateNever]
        public virtual ICollection<Registration> Registrations { get; set; }
	}
}
