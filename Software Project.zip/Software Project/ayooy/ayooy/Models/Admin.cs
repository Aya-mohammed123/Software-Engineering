﻿using ayooy.Models.Account;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ayooy.Models
{
	public class Admin
	{
		 

		[Key, ForeignKey("User")]
		public int Id { get; set; }

		public string Name { get; set; }

		// Navigation property to the associated User
		public virtual User User { get; set; }

		// Navigation property for Faculty (1:M relationship)
		public int FacultyId { get; set; }
		public virtual Faculty Faculty { get; set; }
	}
}
