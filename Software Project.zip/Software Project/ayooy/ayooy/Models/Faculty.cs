﻿using System.ComponentModel.DataAnnotations;

namespace ayooy.Models
{
	public class Faculty
	{
		[Key]
		public int Id { get; set; }
		public string Name { get; set; }

		// Navigation property for Students (1:M relationship)
		public virtual ICollection<Student> Students { get; set; }

		// Navigation property for Admins (1:M relationship)
		public virtual ICollection<Admin> Admins { get; set; }
	}
}
