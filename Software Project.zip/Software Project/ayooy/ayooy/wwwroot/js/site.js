﻿
	document.getElementById('registrationForm').addEventListener('submit', function (event) {
		event.preventDefault(); // Prevent the default form submission

		// Get values from the form fields
		var username = document.getElementById('Username').value;
		var email = document.getElementById('Email').value;
		var mobile = document.getElementById('Mobile').value;
		var password = document.getElementById('Password').value;
	 

		// Create an object with the user data
		var userData = {
			Username: username,
			Email: email,
			Mobile: mobile,
			Password: password,
		};

		// Create an array or push the object into an existing array
		var userArray = []; // You can initialize this array elsewhere in your code if needed
		userArray.push(userData);

		// Now you have the user data in the userArray
		console.log(userArray);

		// You can perform further actions, such as sending the data to the server via AJAX
		 
		window.location.href = '/Courses/Indexx';
		// Optionally, you can reset the form
		document.getElementById('registrationForm').reset();
		window.location.href = '/Courses/Indexx';

	});
