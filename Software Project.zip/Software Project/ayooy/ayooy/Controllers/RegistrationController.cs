﻿using ayooy.Data;
using ayooy.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ayooy.Controllers
{
	public class RegistrationController : Controller
	{
		private readonly AppDbContext _context;
		public RegistrationController(AppDbContext context)
		{
			_context = context;
		}
        //public IActionResult Index()
        //{
        //	IEnumerable<Course> reglist = _context.Courses;
        //	return View(reglist);
        //}
        public IActionResult Index()
        {
            var registrations = _context.Registrations.ToList();
            return View(registrations);
        }
        // Action to show a form for creating a new registration
        public IActionResult Create()
        {
            // Populate dropdowns or perform any other necessary setup
            ViewBag.Students = _context.Students.ToList();
            ViewBag.Courses = _context.Courses.ToList();

            return View();
        }

        // Action to handle the form submission and create a new registration
        [HttpPost]
        public IActionResult Create(Registration registration)
        {
            if (ModelState.IsValid)
            {
                _context.Registrations.Add(registration);
                _context.SaveChanges();
                return RedirectToAction("Index");
            }

            // Repopulate dropdowns in case of validation errors
            ViewBag.Students = _context.Students.ToList();
            ViewBag.Courses = _context.Courses.ToList();

            return View(registration);
        }
    }
}
