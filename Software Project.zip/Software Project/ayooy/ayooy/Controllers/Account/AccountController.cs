﻿using ayooy.Data;
using ayooy.Models;
using ayooy.Models.Account;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace ayooy.Controllers.Account
{
	public class AccountController : Controller
	{
        private readonly AppDbContext _context;
        public AccountController(AppDbContext context)
        {
            _context = context;
        }
        public IActionResult Index()
		{
            IEnumerable<User> users = _context.Users;
            return View(users);
        }
		public IActionResult Login()
		{
			return View();
		}
		[HttpPost]
		public IActionResult Login(LoginSignupViewModel loginSignupViewModel)
		{ 
            if(ModelState.IsValid)
            {
                var data=_context.Users.Where(e=>e.Username==loginSignupViewModel.Username).SingleOrDefault();
                if(data!=null)
                {
                    bool isValid=(data.Username==loginSignupViewModel.Username&&data.Password==loginSignupViewModel.Password);
                    if(isValid)
                    {
                        var identity = new ClaimsIdentity(new[] { new Claim(ClaimTypes.Name, loginSignupViewModel.Username) },
                            CookiesAuthticationDefaults.AuthticationScheme);
                        var principal=new ClaimsPrincipal(identity);
                        HttpContext.SignInAsync(CookiesAuthticationDefaults.AuthticationScheme, principal);
                        HttpContext.Session.SetString("Username", loginSignupViewModel.Username);
                        return RedirectToAction("Index","Home");
                    }
                    else
                    {
                        TempData["errorMessage"] = "Invalid password!";
                        return View(loginSignupViewModel);
                    }
                } 
                else 
                {
                    TempData["errorMessage"] = " Username not found!";
                    return View(loginSignupViewModel);
                }
            }
            else
            {
                return View(loginSignupViewModel);
            }
        }
        public IActionResult LogOut()
        {
            HttpContext.SignOutAsync(CookiesAuthticationDefaults.AuthticationScheme);
            return RedirectToAction("Login","Account");
        }
        public IActionResult SignUp()
		{
			return View();
		}
		[HttpPost]
		public IActionResult SignUp(User loginSignupViewModel)
		{
            if (ModelState.IsValid)
            {
                _context.Add(loginSignupViewModel);
                _context.SaveChanges();
                return RedirectToAction();
            }
            return RedirectToAction();
        }
	}
}
