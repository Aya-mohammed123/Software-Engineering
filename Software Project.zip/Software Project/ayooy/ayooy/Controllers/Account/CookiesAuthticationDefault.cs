﻿namespace ayooy.Controllers.Account
{
    internal class CookiesAuthticationDefaults
    {
        public static string? AuthticationScheme { get; internal set; }
    }
}