﻿using ayooy.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ayooy.Controllers
{

	public class StudentsController : Controller
	{
		private readonly AppDbContext _context;
		public StudentsController(AppDbContext context)
		{
			_context = context;
		}
		public async Task<IActionResult> Index(string? search)
		{

			ViewBag.Search = search;

			if (string.IsNullOrEmpty(search) == true)
			{
				var appDbContext = _context.Students.Include(d => d.Faculty /*Fk which the search process depends */);
				return View(await appDbContext.ToListAsync());
			}
			else
			{
				return View("Index", _context.Students.Include(d => d.Faculty/*Fk which the search process depends */).Where(d => d.Name.Contains(search)).ToList());
			}
		}
	}
}
