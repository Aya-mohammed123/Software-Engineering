﻿using ayooy.Models.Account;
using ayooy.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace ayooy.Data
{
	public class AppDbContext : IdentityDbContext
	{
		public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
		{

		}
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);


			modelBuilder.Entity<User>()
				.HasOne(u => u.Student)
				.WithOne(s => s.User)
				.HasForeignKey<Student>(s => s.Id);

			modelBuilder.Entity<User>()
				.HasOne(u => u.Admin)
				.WithOne(a => a.User)
				.HasForeignKey<Admin>(a => a.Id);
			modelBuilder.Entity<Student>()
			.HasOne(s => s.Faculty)
			.WithMany(f => f.Students)
			.HasForeignKey(s => s.FacultyId);

			modelBuilder.Entity<Admin>()
				.HasOne(a => a.Faculty)
				.WithMany(f => f.Admins)
				.HasForeignKey(a => a.FacultyId);


			//(M:M)
			modelBuilder.Entity<Registration>()
		   .HasKey(sc => new { sc.StudentId, sc.CourseId });

			modelBuilder.Entity<Registration>()
				.HasOne(sc => sc.Student)
				.WithMany(s => s.Registrations)
				.HasForeignKey(sc => sc.StudentId);

			modelBuilder.Entity<Registration>()
				.HasOne(sc => sc.Course)
				.WithMany(c => c.Registrations)
				.HasForeignKey(sc => sc.CourseId);
		}
		public DbSet<User> Users { get; set; }
		public DbSet<Student> Students { get; set; }
		public DbSet<Admin> Admins { get; set; }
		public DbSet<Faculty> Faculties { get; set; }
		public DbSet<Course> Courses { get; set; }
		public DbSet<Registration> Registrations { get; set; }
	}
}
